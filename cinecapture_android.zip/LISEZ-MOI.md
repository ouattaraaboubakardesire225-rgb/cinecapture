# CinéCapture Android (Capacitor)

À faire sur un ordinateur avec Node.js 20+ et Android Studio installés.

```bash
cd cinecapture_android
npm init -y            # seulement si package.json est absent
npm install @capacitor/core @capacitor/android @capacitor/browser
npm install -D @capacitor/cli @capacitor/assets
npx cap add android
npx capacitor-assets generate --android   # icône et écran de démarrage depuis resources/
npx cap sync android
npx cap open android                      # ouvre Android Studio
```

Dans Android Studio : *Build > Build Bundle(s) / APK(s) > Build APK(s)* pour un fichier à installer, ou *Generate Signed Bundle* (AAB) pour le Play Store.

## Avant de compiler

1. Ouvre `www/index.html` et renseigne l'adresse de ton serveur tout en haut :
   `window.CINECAPTURE_API = 'https://ton-api.exemple.com';`
   Vide, l'application reste en démonstration (pas de vrai compte, pas de vrai paiement).
2. Sur le serveur, autorise l'application dans le CORS. Dans une application Capacitor, l'origine est `https://localhost` :
   ```python
   app.add_middleware(CORSMiddleware,
       allow_origins=["https://localhost", "capacitor://localhost"],
       allow_methods=["*"], allow_headers=["*"])
   ```
3. Dans `.env` du serveur, `APP_URL` doit pointer vers une page web qui rappelle à l'utilisateur de revenir dans l'application. Après le paiement, il revient lui-même dans l'application et touche « J'ai déjà payé, vérifier ».

## À savoir

- Le paiement s'ouvre dans le navigateur du téléphone (plugin `@capacitor/browser`).
- Google Play peut exiger son propre système de facturation pour des abonnements numériques. Lis ses règles avant de publier.
- Mets à jour `www/index.html`, puis relance `npx cap sync android` à chaque modification.
